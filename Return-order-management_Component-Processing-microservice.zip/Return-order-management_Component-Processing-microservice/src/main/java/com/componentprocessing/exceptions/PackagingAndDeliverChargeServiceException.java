package com.componentprocessing.exceptions;

public class PackagingAndDeliverChargeServiceException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PackagingAndDeliverChargeServiceException(String message) {
		super(message);

	}

}
