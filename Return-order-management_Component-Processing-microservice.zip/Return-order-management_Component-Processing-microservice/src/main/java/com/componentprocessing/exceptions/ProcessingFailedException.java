package com.componentprocessing.exceptions;

public class ProcessingFailedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProcessingFailedException() {
		super();
	}

}
