package com.componentprocessing.exceptions;

public class ConfirmationFailedException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ConfirmationFailedException() {
		super();
	}

}
