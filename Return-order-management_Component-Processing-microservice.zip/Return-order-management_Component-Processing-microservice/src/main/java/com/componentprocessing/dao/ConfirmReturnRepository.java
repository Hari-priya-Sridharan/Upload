package com.componentprocessing.dao;

import com.componentprocessing.model.ConfirmReturn;

public interface ConfirmReturnRepository {

	ConfirmReturn saveReturnConfirmation(ConfirmReturn confirmReturn);
}
