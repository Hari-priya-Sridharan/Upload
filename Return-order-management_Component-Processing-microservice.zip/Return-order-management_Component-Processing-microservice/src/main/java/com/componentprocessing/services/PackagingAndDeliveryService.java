package com.componentprocessing.services;

public interface PackagingAndDeliveryService {
	long getPackagingAndDeliveryCharge(String componentType, Integer count);
}
