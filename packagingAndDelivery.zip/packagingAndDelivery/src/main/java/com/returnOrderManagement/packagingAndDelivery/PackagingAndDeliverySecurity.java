/**
 * 
 */
package com.returnOrderManagement.packagingAndDelivery;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * @author 842186
 *
 */
@Configuration
@EnableWebSecurity
public class PackagingAndDeliverySecurity extends WebSecurityConfigurerAdapter{
	 private static final String[] AUTH_WHITELIST = {

	            // -- swagger ui
	            "/swagger-resources/**",
	            "/swagger-ui.html",
	            "/v2/api-docs",
	            "/webjars/**"
	    };
	 @Override
	    protected void configure(HttpSecurity http) throws Exception {
	        http.csrf().disable().authorizeRequests()
	                .antMatchers("/", "/GetPackagingDeliveryCharge","/h2-console/**").permitAll()
	                .antMatchers(AUTH_WHITELIST).permitAll();
	        http.headers().frameOptions().disable();
	          
	    }

}
