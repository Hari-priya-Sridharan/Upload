/**
 * 
 */
package com.returnOrderManagement.packagingAndDelivery;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.Setter;

/**
 * @author 842186
 *
 */
@Entity
@Getter
@Setter
public class componentAndCharges {
	@Id
	@NotNull
	private int componentTypeId;
	@Column
	@NotNull
	private String  componentTypeName;
	@Column
	@NotNull
	private String componentTypeMode;
	@Column
	@NotNull
	private String componentTypeCharge;
	
	
}
