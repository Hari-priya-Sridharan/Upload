package com.returnOrderManagement.packagingAndDelivery;


import javax.validation.constraints.*;

import org.springframework.validation.annotation.Validated;

public record PackagingAndDeliveryRequest(
		@NotNull String componentType,
		 @Min(value=1) int count		) {
}
