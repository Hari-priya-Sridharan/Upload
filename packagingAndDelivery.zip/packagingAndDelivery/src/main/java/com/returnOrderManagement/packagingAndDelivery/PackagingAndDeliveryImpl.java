///**
// * 
// */
//package com.returnOrderManagement.packagingAndDelivery;
//
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Repository;
//
///**
// * @author 842186
// *
// */
//@Repository
//public class PackagingAndDeliveryImpl implements PackagingAndDeliveryRepository{
//	
//	@Autowired
//	PackagingAndDelivery packagingAndDelivery;
////	@Autowired
////	PackagingAndDeliveryRepository packagingAndDeliveryRepo;
//	
////	public PackagingAndDelivery findCharge() {
//	@Override
//	public List<Integer> retrievePackagingCost(String componentType){
//		
//		return null;
//		
//	}
//	public void findCharge() {
//	
//			List<Integer> list=packagingAndDeliveryRepo.retrievePackagingCost("Integral item");
//			System.out.println(list.toString());
//			
//	//		//*******Create packageAndDelivery object*******//
//	//		pd.setAccessoryDeliveryCost(accessoryDeliveryCost);
//	//		pd.setAccessoryPackageCost(accessoryPackageCost);
//	//		pd.setIntegralItemDeliveryCost(integralItemDeliveryCost);
//	//		pd.setIntegralItemPackageCost(integralItemPackageCost);
//	//		pd.setSheathPackageCost(sheathPackageCost);
//	//		//*******logging*******//
//	//		log.info("accessoryDeliveryCost={}",pd.getAccessoryDeliveryCost());
//	//		log.info("accessoryPackageCost={}",pd.getAccessoryPackageCost());
//	//		log.info("integralItemDeliveryCost={}",pd.getIntegralItemDeliveryCost());
//	//		log.info("integralItemPackageCost={}",pd.getIntegralItemPackageCost());
//	//		log.info("sheathPackageCost={}",pd.getSheathPackageCost());
////			return pd;
//			
//		}
//	
//}
