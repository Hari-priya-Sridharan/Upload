package com.returnOrderManagement.packagingAndDelivery;

import org.springframework.stereotype.Component;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
public class PackagingAndDelivery {
	private int integralItemPackageCost;
	private int accessoryPackageCost;
	private int sheathPackageCost;
	private int integralItemDeliveryCost;
	private int accessoryDeliveryCost;
	
	public int getIntegralItemPackageCost() {
		return integralItemPackageCost;
	}
	public void setIntegralItemPackageCost(int integralItemPackageCost) {
		this.integralItemPackageCost = integralItemPackageCost;
	}
	public int getAccessoryPackageCost() {
		return accessoryPackageCost;
	}
	public void setAccessoryPackageCost(int accessoryPackageCost) {
		this.accessoryPackageCost = accessoryPackageCost;
	}
	public int getSheathPackageCost() {
		return sheathPackageCost;
	}
	public void setSheathPackageCost(int sheathPackageCost) {
		this.sheathPackageCost = sheathPackageCost;
	}
	public int getIntegralItemDeliveryCost() {
		return integralItemDeliveryCost;
	}
	public void setIntegralItemDeliveryCost(int integralItemDeliveryCost) {
		this.integralItemDeliveryCost = integralItemDeliveryCost;
	}
	public int getAccessoryDeliveryCost() {
		return accessoryDeliveryCost;
	}
	public void setAccessoryDeliveryCost(int accessoryDeliveryCost) {
		this.accessoryDeliveryCost = accessoryDeliveryCost;
	}
	
}
