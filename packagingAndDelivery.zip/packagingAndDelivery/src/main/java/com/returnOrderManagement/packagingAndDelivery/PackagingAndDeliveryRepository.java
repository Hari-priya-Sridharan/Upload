///**
// * 
// */
//package com.returnOrderManagement.packagingAndDelivery;
//
//import java.util.List;
//
//import javax.persistence.Entity;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.data.jpa.repository.Query;
//import org.springframework.stereotype.Repository;
//
///**
// * @author 842186
// *
// */
//
//public interface PackagingAndDeliveryRepository extends JpaRepository<componentAndCharges,Integer>{
//	
//	@Query("SELECT c FROM COMPONENTTYPE c WHERE COMPONENTTYPE_NAME LIKE ?1 AND (COMPONENTTYPE_COST LIKE 'Packaging' AND COMPONENTTYPE_COST LIKE 'Delivery') ")
//	public componentAndCharges retrievePackagingCost(String componentType);
//}
