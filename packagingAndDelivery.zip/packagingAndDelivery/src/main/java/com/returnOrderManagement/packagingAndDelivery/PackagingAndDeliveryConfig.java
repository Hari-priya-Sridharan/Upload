package com.returnOrderManagement.packagingAndDelivery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
/* INFO-
 * Purpose: 
 * The purpose of this class is to set predefined values to the cost of each item. 
 * The default values are added to the config.properties file
 * 
 * Function :
 * Sets the value of variables in packageAndDelivery.java class using setters.
 * 
 * Calls: 
 * Setters from packageAndDelivery.java
 */
//=============================Imports======================//
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import lombok.Getter;
import lombok.Setter;

//=======================Class Definition====================//
@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "cost")
public class PackagingAndDeliveryConfig {
	
	private int integralItemPackageCost;
	private int accessoryPackageCost;
	private int sheathPackageCost;
	private int integralItemDeliveryCost;
	private int accessoryDeliveryCost;

	private static final Logger log = LoggerFactory.getLogger(PackagingAndDeliveryController.class);
	//------------Set pre-defined values to packageAndDelivery object----------//
	public PackagingAndDelivery setPredefinedCost() {
		
		//*******Create packageAndDelivery object*******//
			integralItemPackageCost = 100; 
			accessoryPackageCost = 50; 	
			sheathPackageCost = 50;
			integralItemDeliveryCost = 200;
			accessoryDeliveryCost = 100;
		PackagingAndDelivery pd=new PackagingAndDelivery();
		//*******calling setter to set the cost*******/
		
		pd.setAccessoryDeliveryCost(accessoryDeliveryCost);
		pd.setAccessoryPackageCost(accessoryPackageCost);
		pd.setIntegralItemDeliveryCost(integralItemDeliveryCost);
		pd.setIntegralItemPackageCost(integralItemPackageCost);
		pd.setSheathPackageCost(sheathPackageCost);
		//*******logging*******//
		log.info("accessoryDeliveryCost={}",pd.getAccessoryDeliveryCost());
		log.info("accessoryPackageCost={}",pd.getAccessoryPackageCost());
		log.info("integralItemDeliveryCost={}",pd.getIntegralItemDeliveryCost());
		log.info("integralItemPackageCost={}",pd.getIntegralItemPackageCost());
		log.info("sheathPackageCost={}",pd.getSheathPackageCost());
		return pd;
		
	}
	
}
