INSERT INTO 
	componentType (componentType_name,componentType_mode,componentType_charge) 
VALUES 
	('Integral item','Packaging','100'),
	('Accessory','Packaging','50'),
	('Protective Sheath','Packaging','50'),
	('Integral item','Delivery','200'),
	('Accessory','Delivery','100');
	