CREATE TABLE IF NOT EXISTS componentType (
  	componentType_id          SERIAL PRIMARY KEY
  , componentType_name 		VARCHAR(64) NOT NULL
  ,	componentType_mode 		VARCHAR(64) NOT NULL
  , componentType_charge 	INTEGER NOT NULL
 );
