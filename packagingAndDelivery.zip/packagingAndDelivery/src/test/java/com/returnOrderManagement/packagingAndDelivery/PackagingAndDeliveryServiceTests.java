package com.returnOrderManagement.packagingAndDelivery;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;

public class PackagingAndDeliveryServiceTests {
	 @Mock
	   private PackagingAndDeliveryService pdService = new PackagingAndDeliveryService();
	 @Mock
	 	private PackagingAndDelivery pd= new PackagingAndDelivery(); 

	 @Test
	   public void testCalculatePackagingDeliveryCharge(){
	   
//	      when(pdService.calculatePackagingDeliveryCharge(new PackagingAndDeliveryRequest("Integral item",3))).thenReturn(600);
	   	 
	      assertEquals(1050,pdService.calculatePackagingDeliveryCharge(new PackagingAndDeliveryRequest("Integral item",3)));
	      assertEquals(1000,pdService.calculatePackagingDeliveryCharge(new PackagingAndDeliveryRequest("Accessory",5)));
	      assertEquals(-1,pdService.calculatePackagingDeliveryCharge(new PackagingAndDeliveryRequest("Other",2)));
	 } 	

}
