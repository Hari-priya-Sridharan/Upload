package com.packagingandelivery.services;

public interface ChargeCalculationService {

	public Long calculateChargeforComponent(String componentType, int count);
}
