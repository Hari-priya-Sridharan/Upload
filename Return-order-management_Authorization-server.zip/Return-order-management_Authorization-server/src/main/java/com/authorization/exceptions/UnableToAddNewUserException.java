package com.authorization.exceptions;

public class UnableToAddNewUserException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7676088894966093231L;

	public UnableToAddNewUserException() {
		super();
	}

}
