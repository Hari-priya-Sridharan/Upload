package com.authorization.exceptions;

public class RoleNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3831841078018203106L;

	public RoleNotFoundException() {
		super();
	}

}
